from pathlib import Path


# ============================================================
# Configuration
# ============================================================

TEMPLATE_FILE = Path("benchmark_master.txt")
OUTPUT_DIR = Path(".")

DATASETS = (
    "blobs10",
    "circles",
    "moons",
)


METHODS = {
    "our": {
        "import": "from DBCV import DBCV_score",

        "config": "",

        "call": """score = DBCV_score(
            X,
            labels,
            n_jobs=1,
        )""",
    },

    "hdbscan": {
        "import": "from hdbscan.validity import validity_index",

        "config": "",

        "call": """score = validity_index(
            X,
            labels,
            metric='sqeuclidean',
        )""",
    },

    "kdbcv": {
        "import": "from kDBCV import DBCV_score",

        "config": """# KDBCV memory cutoff, in GB.
MEM_CUTOFF = 100""",

        "call": """score = DBCV_score(
            X,
            labels,
            mem_cutoff=MEM_CUTOFF,
        )[0]""",
    },

    "felsiq": {
        "import": "from dbcv import dbcv",

        "config": "",

        "call": """score = dbcv(
            X,
            labels,
            n_processes=1,
            use_original_mst_implementation=True,
        )""",
    },
}


# ============================================================
# Generation
# ============================================================

def generate(template: str, method: str, dataset: str) -> str:

    spec = METHODS[method]

    replacements = {
        "<IMPORT_HERE>": spec["import"],
        "<METHOD_HERE>": method,
        "<DATASET_HERE>": dataset,
        "<METHOD_CONFIG_HERE>": spec["config"],
        "<DBCV_CALL_HERE>": spec["call"],
    }

    script = template

    for placeholder, value in replacements.items():
        script = script.replace(
            placeholder,
            value,
        )

    remaining = [
        placeholder
        for placeholder in replacements
        if placeholder in script
    ]

    if remaining:
        raise RuntimeError(
            f"Unresolved placeholders in "
            f"{method}/{dataset}: {remaining}"
        )

    return script


def main():

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    template = TEMPLATE_FILE.read_text()

    for method in METHODS:

        for dataset in DATASETS:

            script = generate(
                template,
                method,
                dataset,
            )

            output = (
                OUTPUT_DIR
                / f"benchmark_{method}_{dataset}.py"
            )

            output.write_text(script)

            print(output)


if __name__ == "__main__":
    main()
