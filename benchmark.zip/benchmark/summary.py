from pathlib import Path
import json

import pandas as pd


# ============================================================
# Configuration
# ============================================================

RESULT_DIR = Path("results")
OUTPUT_DIR = Path("summary")

DATASETS = (
    "blobs10",
    "circles",
    "moons",
)

METHODS = (
    "our",
    "hdbscan",
    "kdbcv",
    "felsiq",
)

RUNS = (1, 2, 3)

SIZES = (
    500,
    1000,
    5000,
    10000,
    25000,
    50000,
    100000,
)


# ============================================================
# Load results
# ============================================================

def load_results():

    records = []

    for method in METHODS:

        for dataset in DATASETS:

            for n in SIZES:

                path = (
                    RESULT_DIR
                    / method
                    / dataset
                    / f"N{n}.json"
                )

                runs = {}

                if path.exists():

                    try:
                        with path.open() as f:
                            data = json.load(f)

                        for result in data.get("runs", []):
                            run = result.get("run")

                            if run in RUNS:
                                runs[run] = result

                    except (
                        OSError,
                        json.JSONDecodeError,
                    ):
                        pass

                # Always create all three run entries.
                # Missing/failed runs remain NaN.
                for run in RUNS:

                    result = runs.get(run)

                    if (
                        result is not None
                        and result.get("status") == "success"
                    ):
                        time = result.get(
                            "score_time_sec"
                        )

                        memory = result.get(
                            "peak_rss_mb"
                        )

                        score = result.get(
                            "score"
                        )

                    else:
                        time = float("nan")
                        memory = float("nan")
                        score = float("nan")

                    records.append(
                        {
                            "dataset": dataset,
                            "method": method,
                            "run": run,
                            "N": n,
                            "time": time,
                            "peak_memory": memory,
                            "score": score,
                        }
                    )

    return pd.DataFrame(records)


# ============================================================
# Construct one table
# ============================================================

def make_table(
    df: pd.DataFrame,
    value_column: str,
) -> pd.DataFrame:

    table = (
        df.pivot(
            index=["method", "run"],
            columns="N",
            values=value_column,
        )
        .reindex(
            index=pd.MultiIndex.from_product(
                [METHODS, RUNS],
                names=["method", "run"],
            ),
            columns=SIZES,
        )
    )

    table.index.names = [
        "method",
        "run",
    ]

    table.columns.name = "N"

    return table


# ============================================================
# Main
# ============================================================

def main():

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    df = load_results()

    for dataset in DATASETS:

        dataset_df = df[
            df["dataset"] == dataset
        ]

        runtime = make_table(
            dataset_df,
            "time",
        )

        peak_memory = make_table(
            dataset_df,
            "peak_memory",
        )

        score = make_table(
            dataset_df,
            "score",
        )

        # ----------------------------------------------------
        # One directory per dataset.
        # ----------------------------------------------------

        dataset_dir = (
            OUTPUT_DIR / dataset
        )

        dataset_dir.mkdir(
            parents=True,
            exist_ok=True,
        )

        runtime.to_csv(
            dataset_dir / "runtime.csv"
        )

        peak_memory.to_csv(
            dataset_dir / "peak_memory.csv"
        )

        score.to_csv(
            dataset_dir / "score.csv"
        )

        # ----------------------------------------------------
        # Console output
        # ----------------------------------------------------

        print()
        print("=" * 80)
        print(dataset)
        print("=" * 80)

        print("\nTIME")
        print(runtime)

        print("\nPEAK MEMORY")
        print(peak_memory)

        print("\nSCORE")
        print(score)


if __name__ == "__main__":
    main()