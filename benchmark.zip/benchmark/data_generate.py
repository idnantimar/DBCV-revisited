import json
from pathlib import Path

import numpy as np
from sklearn.datasets import make_blobs, make_circles, make_moons


# ============================================================
# Configuration
# ============================================================

N_MAX = 100_000

DATASETS = (
    "moons",
    "circles",
    "blobs10",
)

RANDOM_STATE = 20262008

DATA_DIR = Path("data")


# ============================================================
# Data generation
# ============================================================

def generate_data(dataset, n):
    if dataset == "moons":
        X, labels = make_moons(
            n_samples=n,
            noise=0.05,
            random_state=RANDOM_STATE,
        )

    if dataset == "circles":
        X, labels = make_circles(
            n_samples=n,
            noise=0.03,
            factor=0.5,
            random_state=RANDOM_STATE,
        )

    if dataset == "blobs10":
        X, labels = make_blobs(
            n_samples=n,
            centers=10,
            n_features=2,
            cluster_std=0.60,
            random_state=RANDOM_STATE,
        )

    return (
        X.astype(np.float64, copy=False),
        labels.astype(np.int64, copy=False),
    )


# ============================================================
# Main
# ============================================================

def main():

    DATA_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    for dataset in DATASETS:

        print(f"\n{'=' * 70}")
        print(dataset)
        print(f"{'=' * 70}")

        print(
            f"Generating {N_MAX:,} observations..."
        )

        X, labels = generate_data(
            dataset,
            N_MAX,
        )

        order = np.argsort(labels, kind="stable")
        X, labels = X[order], labels[order]

        n_clusters = np.unique(labels).size

        cluster_sizes = np.bincount(labels)

        output_path = (
            DATA_DIR
            / f"{dataset}_{N_MAX}.npz"
        )

        np.savez(
            output_path,
            X=X,
            labels=labels,
        )

        metadata = {
            "dataset": dataset,
            "n": N_MAX,
            "random_state": RANDOM_STATE,
            "n_clusters": int(n_clusters),
            "cluster_sizes": cluster_sizes.tolist(),
            "path": str(output_path),
        }

        metadata_path = (
            DATA_DIR
            / f"{dataset}_{N_MAX}.json"
        )

        with metadata_path.open("w") as f:
            json.dump(
                metadata,
                f,
                indent=2,
            )

        print(
            f"saved: {output_path}"
        )

        print(
            f"clusters={n_clusters}"
            f" | cluster_sizes={cluster_sizes.tolist()}"
        )


if __name__ == "__main__":
    main()